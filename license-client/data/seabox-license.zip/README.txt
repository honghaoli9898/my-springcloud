1、新版License向下兼容，兼容低版；
2、seaboxdata-commons-v7.1.jar包需要复制到对应服务的CLASSPATH下，然后重启服务；
2、部署方式和老版一样



